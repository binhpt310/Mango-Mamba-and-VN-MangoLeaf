# MangoMamba - Cài đặt, tái lập thực nghiệm và nguồn hình luận văn

Repository lưu mã nguồn và bằng chứng thực nghiệm cho luận văn **Phát triển mô hình Deep Learning cải tiến dựa trên Mamba để chẩn đoán và dự đoán các loại bệnh phổ biến trên lá xoài** của **Phạm Thanh Bình**, Trường Đại học Công nghệ Thông tin, năm 2026.

Tài liệu này gộp hướng dẫn cài môi trường từ host `asus`, mục đích các script Python chính, lệnh chạy 36 lượt thực nghiệm và nguồn gốc các hình liên quan. Mọi lệnh huấn luyện chạy từ thư mục gốc repository trong Bash trên Linux/WSL2 có GPU NVIDIA. Các lệnh PowerShell được ghi riêng.

## Mục lục

| Mục | Nội dung |
|---|---|
| [1. Tổng quan](#tong-quan) | Phạm vi, kết quả và cấu trúc repository |
| [2. Kiến trúc và quy trình](#kien-truc) | Hình 3.1, 3.2, 3.3 và mã liên quan |
| [3. Môi trường và cài đặt](#cai-dat) | Venv trên asus, cài lại Linux/WSL2, kiểm tra CUDA |
| [4. Dữ liệu và checkpoint](#du-lieu) | Split, ánh xạ nhãn, vị trí dữ liệu và trọng số |
| [5. Script Python chính](#scripts) | Mục đích và đầu ra của các file cần dùng |
| [6. Chạy thực nghiệm](#chay-thuc-nghiem) | Ba giai đoạn, direct-VN, năm ablation và bốn seed |
| [7. Tổng hợp kết quả](#ket-qua) | Mean ± sample SD, ánh xạ Bảng 4.1-4.9 |
| [8. Hình thực nghiệm](#hinh-thuc-nghiem) | Hình 4.1-4.8 từ PDF và nguồn dữ liệu/script |
| [9. Phân tích và đo GPU](#phan-tich) | Phân tích lỗi, ghép hình, latency FP32 |
| [10. ONNX và Android](#android) | Xuất model CAM, build và kiểm tra thiết bị |
| [11. Nguồn và giới hạn kiểm tra](#nguon) | Manifest, checksum, log và phần chưa tái lập |

<a id="tong-quan"></a>

## 1. Tổng quan và cấu trúc repository

Mô hình chính dùng ảnh 320×320, cửa sổ `[8,8,5,5]`, hybrid Mamba/LKA, ECA/GRN/SwiGLU và inter-window Mamba ở stage 0. Khảo sát thành phần dùng ảnh 224×224, cửa sổ `[8,8,14,7]`, tắt inter-window Mamba và giữ LKA cố định.

| Thực nghiệm | Tập kiểm tra | Test Accuracy, bốn seed (%) |
|---|---:|---:|
| Giai đoạn 1: MangoLeafBD | 400 ảnh | 99,69 ± 0,24 |
| Giai đoạn 2: Bộ dữ liệu kết hợp | 4.000 ảnh | 99,48 ± 0,07 |
| Giai đoạn 3: VN-MangoLeaf | 700 ảnh | 98,89 ± 0,29 |
| Tinh chỉnh trực tiếp phase 1 -> VN-MangoLeaf | 700 ảnh | 98,11 ± 0,55 |

Các số trên được tính từ `training_results.json → test_metrics` của checkpoint có validation loss nhỏ nhất trong từng lượt. Độ lệch chuẩn là sample SD giữa seed `42, 123, 2024, 3333`; Precision/Recall/F1 dùng trung bình weighted. Đây là bằng chứng đã lưu, chưa phải kết quả chạy lại mới trong lần chuẩn bị hướng dẫn này.

| Vị trí | Nội dung |
|---|---|
| [code/](code/) | Model, trainer, runner, phân tích, đo latency, xuất ONNX và ghép hình |
| [experiments/](experiments/) | 36 lượt kết quả; mỗi case/seed ở một thư mục trực tiếp |
| [environment/](environment/) | Requirements, script cài, bản xuất môi trường và log kiểm tra |
| [docs/figures/](docs/figures/) | Hình thí nghiệm gốc, hình trích PDF và manifest nguồn ảnh |
| [android/](android/) | Ứng dụng Android dùng model 320px có CAM |
| `data/` | Dữ liệu ảnh cục bộ, không có sẵn đầy đủ trong checkout |
| `runs/` | Output dành cho lượt chạy mới |

Luận văn phát triển từ [bài báo Mango-Mamba and VN-MangoLeaf của tác giả](docs/references/Mango-Mamba%20and%20VN-MangoLeaf.pdf). Kết quả trong README đối chiếu với [Luận văn thạc sĩ.pdf](Luận%20văn%20thạc%20sĩ.pdf) và JSON hiện có; các số cũ trong bài báo không thay thế các bảng thực nghiệm mới của luận văn.

<a id="kien-truc"></a>

## 2. Kiến trúc và quy trình huấn luyện

Các ảnh có tiền tố `thesis_fig_` bên dưới được trích đúng vùng hình trên trang PDF sang PNG nền trắng, giữ nội dung và tỷ lệ của bản gốc. Hình 4.7/4.8 được ghép dọc các panel theo đúng thứ tự trong PDF. Mỗi hình ghi nguồn trình bày trong luận văn và nguồn mã/dữ liệu liên quan; tọa độ trang, object xref và SHA-256 nằm trong [manifest ảnh](docs/figures/thesis_images_manifest.json). Trang PDF đếm từ 1; trang in là số ở chân trang luận văn.

### 2.1. Kiến trúc tổng thể (Hình 3.1)

![Hình 3.1. Kiến trúc tổng thể MangoMamba](docs/figures/thesis_fig_3_1_architecture.png)

Nguồn ảnh: [Hình 3.1, trang in 40, trang PDF 43](Luận%20văn%20thạc%20sĩ.pdf#page=43). Mã triển khai: [mango_mamba.py](code/mango_mamba.py). Bản sơ đồ có thể chỉnh sửa hiện có ở [mango_mamba_architecture.drawio](docs/figures/mango_mamba_architecture.drawio); ảnh hiển thị ở đây được lấy từ PDF.

### 2.2. Cấu trúc block (Hình 3.2)

![Hình 3.2. Cấu trúc một MangoMambaBlock](docs/figures/thesis_fig_3_2_block.png)

Nguồn ảnh: [Hình 3.2, trang in 43, trang PDF 46](Luận%20văn%20thạc%20sĩ.pdf#page=46). Đối chiếu các khối Mamba/LKA và những thành phần ECA, GRN, SwiGLU trong [mango_mamba.py](code/mango_mamba.py); cấu hình bật/tắt khi huấn luyện nằm trong `args.yaml` của từng lượt.

### 2.3. Học theo chương trình ba giai đoạn (Hình 3.3)

![Hình 3.3. Quy trình huấn luyện theo chương trình ba giai đoạn](docs/figures/thesis_fig_3_3_curriculum.png)

Nguồn ảnh: [Hình 3.3, trang in 48, trang PDF 51](Luận%20văn%20thạc%20sĩ.pdf#page=51). [run_curriculum.py](code/run_curriculum.py) thực hiện chuỗi MangoLeafBD -> Combined -> VN-MangoLeaf; [train_mango_mamba.py](code/train_mango_mamba.py) nạp trọng số giai đoạn trước và thay đầu phân loại từ 8 sang 7 lớp ở phase 3. Các file `source_run_manifest.json` trong lượt phase 3/direct-VN giữ đường dẫn checkpoint lịch sử.

<a id="cai-dat"></a>

## 3. Môi trường và cài đặt

Nguồn: `/home/admincsc/workspace/binh/reproduce_mm/.venv-mango`, truy cập qua `ssh asus`. Bộ cấu hình đã xuất nằm trong `environment/asus/`; danh mục file và log ở [mục 11](#nguon). Đây là bản chụp môi trường tại thời điểm xuất, không phải bản ghi phiên bản của từng lượt huấn luyện lịch sử.

| Thành phần | Giá trị kiểm tra trực tiếp trên host |
|---|---|
| Hệ điều hành / CPU | Ubuntu 24.04.4 LTS / `aarch64` (ARM64) |
| Python | CPython 3.12.3 |
| GPU | NVIDIA GB10, 119,63 GiB bộ nhớ, compute capability 12.1 |
| NVIDIA driver | 580.126.09 |
| PyTorch / torchvision | `2.13.0+cu130` / `0.28.0+cu130` |
| CUDA của PyTorch / nvcc | 13.0 / 13.0.88 |
| mamba-ssm / timm / einops | `2.3.2.post1` / `1.0.28` / `0.8.2` |
| grad-cam | `1.5.5` |

Venv chứa thư viện nhị phân ARM64; Windows và WSL2 x86_64 cần cài lại gói phù hợp kiến trúc. Python cũng quy định venv phải được [tạo lại tại vị trí đích](https://docs.python.org/3.12/library/venv.html), do các script có thể chứa đường dẫn tuyệt đối.

### 3.1. Dùng venv hiện có trên asus

Đặt bản workspace hiện tại vào một thư mục riêng trên host, ví dụ `~/workspace/binh/Mango-Mamba-thesis`. Mã tại `reproduce_mm/models/` là cây mã lịch sử khác với `code/mango_mamba.py` của workspace này. Dùng venv cũ làm interpreter cho mã hiện tại:

```bash
ssh asus
cd ~/workspace/binh/Mango-Mamba-thesis
source /home/admincsc/workspace/binh/reproduce_mm/.venv-mango/bin/activate
export MPLBACKEND=Agg
python code/check_environment.py
```

Nếu cần chép workspace từ máy Windows, chạy trong PowerShell tại gốc repo trước khi SSH:

```powershell
ssh asus 'mkdir -p ~/workspace/binh/Mango-Mamba-thesis'
scp -r code README.md asus:~/workspace/binh/Mango-Mamba-thesis/
```

Lệnh này chưa chép `experiments/` và dữ liệu ảnh. Để huấn luyện mới có thể dùng `--data-root /home/admincsc/workspace/binh/reproduce_mm/data`; để đánh giá checkpoint đã có, cần chép thêm lượt tương ứng trong `experiments/`. Thư mục `environment/` chỉ cần chép thêm khi muốn dựng venv mới; dùng venv hiện có không cần tải lại wheel ARM64.

### 3.2. Cài venv mới trên Linux/WSL2

Cần Python 3.12, GPU NVIDIA và driver hỗ trợ CUDA 13.0. Trong WSL2, kiểm tra `nvidia-smi` ngay trong terminal Linux trước. Các lệnh huấn luyện hiện tại bắt buộc CUDA. Gói Mamba gốc cũng yêu cầu [Linux và GPU NVIDIA](https://github.com/state-spaces/mamba/tree/v2.3.2.post1#installation).

Sau khi có các gói hệ thống và CUDA Toolkit cần thiết, có thể dùng `bash environment/setup_linux.sh`. Script tạo `.venv-mango` mới, dùng wheel ARM64 nếu có hoặc build Mamba từ nguồn rồi chạy kiểm tra; dừng nếu đường dẫn đã tồn tại. Các lệnh dưới trình bày từng bước tương ứng để dễ xử lý khi cài đặt lỗi.

```bash
# Ubuntu: cài nếu máy còn thiếu Python/venv/công cụ biên dịch.
sudo apt-get update
sudo apt-get install -y python3.12-venv python3.12-dev build-essential git libgl1 libglib2.0-0

# Chạy tại gốc repo; chọn tên khác nếu .venv-mango đã tồn tại.
test ! -e .venv-mango || { echo '.venv-mango đã tồn tại; chọn đường dẫn mới'; exit 1; }
python3.12 -m venv .venv-mango
source .venv-mango/bin/activate
python -m pip install 'pip==26.1.2' 'setuptools==78.1.0'

# Lấy torch CUDA từ chỉ mục chính thức; khóa các phụ thuộc theo bản xuất host.
python -m pip install \
  --index-url https://pypi.org/simple \
  --extra-index-url https://download.pytorch.org/whl/cu130 \
  -c environment/asus/requirements-host-freeze.txt \
  'torch==2.13.0+cu130' 'torchvision==0.28.0+cu130' \
  -r environment/requirements-training.txt
```

Chỉ mục chính thức có wheel [PyTorch CUDA 13.0](https://download.pytorch.org/whl/cu130/torch/) và [torchvision](https://download.pytorch.org/whl/cu130/torchvision/). File `requirements-training.txt` chọn các gói phục vụ thí nghiệm và phụ thuộc Mamba; file freeze 173 gói giữ bản chụp đầy đủ, gồm cả Jupyter không cần dùng cho các lệnh này.

Cài Mamba sau PyTorch. Chọn đúng một trong hai cách:

| Máy đích | Cách cài |
|---|---|
| Linux ARM64, CPython 3.12, PyTorch 2.13.0+cu130 / CUDA 13.0 | Dùng wheel lấy từ host bên dưới. Wheel chỉ phù hợp bộ ABI này; kiểm tra GPU bằng `check_environment.py`. |
| Linux/WSL2 x86_64 hoặc bộ ABI khác | Biên dịch đúng phiên bản Mamba bằng CUDA Toolkit phù hợp; không dùng wheel ARM64. |

```bash
# Cách A: Linux ARM64 tương ứng host asus.
python -m pip install --no-deps \
  environment/asus/wheels/mamba_ssm-2.3.2.post1-cp312-cp312-linux_aarch64.whl
```

```bash
# Cách B: Linux/WSL2 x86_64, cài CUDA Toolkit 13.0 có nvcc trước.
# Điều chỉnh CUDA_HOME nếu toolkit nằm ở vị trí khác.
export CUDA_HOME=/usr/local/cuda-13.0
export PATH="$CUDA_HOME/bin:$PATH"
nvcc --version
python -m pip install 'wheel==0.47.0'
MAMBA_FORCE_BUILD=TRUE MAX_JOBS=2 python -m pip install \
  --no-build-isolation --no-deps 'mamba-ssm==2.3.2.post1'
```

`--no-build-isolation` giữ PyTorch đã cài khi xây extension, theo [hướng dẫn Mamba cùng phiên bản](https://github.com/state-spaces/mamba/tree/v2.3.2.post1#installation). Không cần cài thêm `causal-conv1d` để chạy đường selective scan mà MangoMamba hiện dùng; venv nguồn không có gói đó.

```bash
export MPLBACKEND=Agg
python -m pip check
python code/check_environment.py
python code/train_mango_mamba.py --help
```

`check_environment.py` dùng dữ liệu ngẫu nhiên, kiểm tra import, AMP forward/backward và FP32 forward của cấu hình 224px/8 lớp và 320px/7 lớp. Chỉ bắt đầu huấn luyện khi lệnh này qua. Trên venv gốc, `pip check` đã báo `nvidia-cusparselt-cu13 0.8.1 is not supported on this platform`; lỗi này được lưu nguyên trong `host-environment.json`. Các kiểm tra mô hình trên venv gốc vẫn qua; không vì thế xem `pip check` là đã sạch.

Muốn xuất ONNX, cài thêm:

```bash
python -m pip install -r environment/requirements-export.txt
```

<a id="du-lieu"></a>

## 4. Chuẩn bị dữ liệu và checkpoint

| Thư mục dưới `data/` | Số lớp | Train | Val | Test |
|---|---:|---:|---:|---:|
| `mangoleafBD` | 8 | 3.200 | 400 | 400 |
| `combined_dataset` | 8 | 32.000 | 4.000 | 4.000 |
| `vn_mangoleaf` | 7 | 5.600 | 700 | 700 |

Mỗi bộ có cấu trúc `train/<tên_lớp>/*`, `val/<tên_lớp>/*`, `test/<tên_lớp>/*`. Số lượng và tên thư mục đã kiểm tra trên host được lưu trong [host-data-inventory.json](environment/asus/host-data-inventory.json). Workspace Windows hiện chưa chứa toàn bộ dữ liệu ảnh. Không chia tập lại ngẫu nhiên nếu mục tiêu là đối chiếu số trong PDF; cần dùng đúng bộ ảnh đã chia trên host. Bản kiểm kê đếm ảnh chưa phải manifest hash từng ảnh nên chưa chứng minh được danh tính toàn bộ split.

Tên thư mục 8 lớp trên host: `Anthracnose`, `Bacterial Canker`, `Cutting Weevil`, `Die Back`, `Gall Midge`, `Healthy`, `Powdery Mildew`, `Sooty Mould`. Với VN-MangoLeaf: `Anthracnose`, `Dieback`, `Gall_Midge`, `Healthy`, `Powdery_Mildew`, `Red_Rust`, `Sooty_Mold`. Giữ nguyên thứ tự ánh xạ nhãn theo thư mục, nhất là khi nạp checkpoint.

Các lệnh dưới dùng biến Bash:

```bash
DATA_ROOT="$PWD/data"
# Nếu đang dùng dữ liệu có sẵn trên asus, dùng dòng sau thay thế:
# DATA_ROOT=/home/admincsc/workspace/binh/reproduce_mm/data
OUT="$PWD/runs/thesis_rerun"
mkdir -p "$OUT"
```

Đã có 16 checkpoint cho phase 1/2/3 và direct-VN trong `experiments/`. Hai mươi lượt ablation còn JSON/YAML/hình, hiện thiếu `model_best.pth.tar`. Chạy vào `runs/` để tạo kết quả mới; runner sẽ bỏ qua lượt đã hoàn tất có cả JSON và checkpoint, còn JSON thiếu checkpoint sẽ báo lỗi.

<a id="scripts"></a>

## 5. Các script Python chính

| File trong `code/` | Mục đích và kết quả cần lấy |
|---|---|
| [mango_mamba.py](code/mango_mamba.py) | Định nghĩa backbone, Mamba/LKA, ECA/GRN/SwiGLU và đầu phân loại. Được các script khác import; không cần chạy riêng. |
| [train_mango_mamba.py](code/train_mango_mamba.py) | Huấn luyện một lượt; lưu checkpoint tốt nhất theo validation loss, `training_results.json`, `args.yaml`, đường cong, ma trận nhầm lẫn và Grad-CAM validation. |
| [run_curriculum.py](code/run_curriculum.py) | Điểm chạy chính cho phase 1, phase 2 -> phase 3, direct-VN và năm ablation; giữ seed và chuỗi checkpoint giữa các giai đoạn. |
| [summarize_thesis_results.py](code/summarize_thesis_results.py) | Đọc 4 seed của mỗi nhóm; xuất CSV mean và sample SD cho các bảng chính, dùng `test_metrics`. Dừng nếu thiếu kết quả hoặc khóa số liệu. |
| [analyze_vn_errors.py](code/analyze_vn_errors.py) | Đánh giá lại checkpoint phase 3 seed 42 trên test VN; xuất chỉ số từng lớp, ảnh sai, CAM và CSV phục vụ Bảng 4.7/Hình 4.8. |
| [measure_gpu_latency.py](code/measure_gpu_latency.py) | Đo model forward FP32 batch 1 bằng CUDA events, 100 warm-up + 500 lần đo; đồng thời đánh giá MangoLeafBD test. |
| [render_thesis_figures.py](code/render_thesis_figures.py) | Ghép Hình 4.6, 4.7, 4.8 từ JSON, Grad-CAM validation và các panel ảnh sai; không huấn luyện hoặc suy luận lại. |
| [export_android_cam.py](code/export_android_cam.py) | Xuất checkpoint VN seed 42 thành ONNX 320px có logits + feature map; kiểm tra ONNX/parity và tạo manifest cho ứng dụng Android. |
| [check_environment.py](code/check_environment.py) | Kiểm tra khả năng chạy trước khi triển khai các lượt dài; không tạo kết quả đánh giá dữ liệu thật. |

<a id="chay-thuc-nghiem"></a>

## 6. Chạy lại 36 lượt thực nghiệm

Runner đã đặt các tham số theo YAML của bộ bằng chứng: AdamW, LR `0.0005`, weight decay `0.01`, cosine, warm-up 5 epoch, tối đa 100 epoch, early stopping theo validation loss với patience 20; batch 64, tích lũy gradient 4 bước, AMP. Mỗi lượt độc lập dùng một seed trong `42 123 2024 3333`.

| Nhóm | Cấu hình | Khởi tạo | Số lượt |
|---|---|---|---:|
| Phase 1 | MangoLeafBD, 8 lớp, 320px | Ngẫu nhiên | 4 |
| Phase 2 | Combined, 8 lớp, 320px | Phase 1 cùng seed | 4 |
| Phase 3 | VN-MangoLeaf, 7 lớp, 320px | Phase 2 cùng seed; đổi đầu phân loại | 4 |
| Direct-VN | VN-MangoLeaf, 7 lớp, 320px | Phase 1 cùng seed; bỏ qua phase 2 | 4 |
| Ablation | MangoLeafBD, 8 lớp, 224px, 5 cấu hình | Ngẫu nhiên, độc lập phase 1 | 20 |

Cấu hình 320px có cửa sổ `[8,8,5,5]`, hybrid Mamba/LKA, đủ ECA/GRN/SwiGLU, inter-window Mamba tại stage 0. Ablation 224px dùng `[8,8,14,7]`, tắt inter-window Mamba và giữ LKA cố định.

```bash
# Một seed để theo dõi quy trình trước.
python code/run_curriculum.py --task phase1 --seed 42 \
  --data-root "$DATA_ROOT" --output "$OUT"
python code/run_curriculum.py --task curriculum --seed 42 \
  --data-root "$DATA_ROOT" --output "$OUT"
python code/run_curriculum.py --task direct-vn --seed 42 \
  --data-root "$DATA_ROOT" --output "$OUT"
```

`curriculum` chạy cả phase 2 rồi phase 3. Dùng vòng lặp sau để hoàn tất đủ 36 lượt; các lượt seed 42 đã hoàn tất sẽ được bỏ qua:

```bash
set -e
for seed in 42 123 2024 3333; do
  python code/run_curriculum.py --task phase1 --seed "$seed" --data-root "$DATA_ROOT" --output "$OUT"
  python code/run_curriculum.py --task curriculum --seed "$seed" --data-root "$DATA_ROOT" --output "$OUT"
  python code/run_curriculum.py --task direct-vn --seed "$seed" --data-root "$DATA_ROOT" --output "$OUT"
  for case in full no_eca no_grn no_swiglu hybrid_minimal; do
    python code/run_curriculum.py --task ablation --case "$case" --seed "$seed" \
      --data-root "$DATA_ROOT" --output "$OUT"
  done
done
```

Vòng lặp chạy tuần tự một trainer. Mỗi thư mục lượt có `train.log` và `invocations.jsonl`; ví dụ `tail -f "$OUT/04_phase3_vn_mangoleaf_320_seed_42/train.log"`. Nếu lượt bị ngắt và còn `last.pth.tar`, runner dùng checkpoint đó để resume. Scheduler, early stopping và lịch sử hình chưa được khôi phục đầy đủ như một lượt chạy liên tục; nên dùng output mới và chạy liên tục khi cần so sánh tái lập chặt chẽ.

Muốn dùng lại phase 1 đã có cho một output mới, chép checkpoint cùng seed trước:

```bash
for seed in 42 123 2024 3333; do
  dst="$OUT/01_phase1_mangoleafbd_320_seed_$seed"
  mkdir -p "$dst"
  cp -n "experiments/01_phase1_mangoleafbd_320_seed_$seed/"{model_best.pth.tar,training_results.json,args.yaml} "$dst/"
done
```

Cách này tái sử dụng phase 1, không được báo là đã huấn luyện lại cả ba giai đoạn. Muốn chạy phase 1 mới từ đầu, dùng vòng lặp 36 lượt với thư mục output rỗng.

<a id="ket-qua"></a>

## 7. Tổng hợp kết quả và đối chiếu bảng

```bash
# Tính lại từ bộ bằng chứng đang có, không cần GPU hoặc dữ liệu ảnh.
python code/summarize_thesis_results.py --experiments experiments > "$OUT/retained_results.csv"

# Sau khi 36 lượt mới đã hoàn tất:
python code/summarize_thesis_results.py --experiments "$OUT" > "$OUT/rerun_results.csv"
```

Accuracy/Precision/Recall/F1 trong `test_metrics` nằm trong khoảng 0-1; script đổi sang phần trăm và tính sample SD (`n-1`) giữa 4 seed. Precision/Recall/F1 là trung bình weighted. Cột `last_epoch_val_loss` lấy `final_metrics.val_loss`, đúng trường dùng trong Bảng 4.4 hiện tại; trường này là loss epoch cuối, không phải loss tốt nhất dùng chọn checkpoint.

| Bảng trong PDF | Nhóm/thao tác | Accuracy tham chiếu (%) |
|---|---|---:|
| 4.3 | Phase 1 | 99,69 ± 0,24 |
| 4.4 | Full / no_eca / no_grn / no_swiglu / hybrid_minimal | 99,44 ± 0,24 / 98,88 ± 0,52 / 99,31 ± 0,31 / 99,31 ± 0,38 / 99,25 ± 0,20 |
| 4.5 | Phase 2 | 99,48 ± 0,07 |
| 4.6 | Phase 3 | 98,89 ± 0,29 |
| 4.7 | `test_per_class_metrics` của phase 3 seed 42 hoặc CSV phân tích lỗi | Checkpoint đúng 695/700 ảnh |
| 4.8 | Ghép phase 3 và direct-VN theo cùng seed | 98,89 ± 0,29 / 98,11 ± 0,55 |
| 4.9 | Dòng MangoMamba từ phase 1 + latency; các dòng còn lại trích tài liệu | 99,69 ± 0,24 |

Kiểm định t ghép cặp cho Bảng 4.8 có thể tính từ kết quả cùng seed:

```bash
python - "$OUT" <<'PY'
import json, sys
from pathlib import Path
from scipy.stats import ttest_rel
root = Path(sys.argv[1])
def scores(case):
    return [json.loads((root / f'{case}_320_seed_{seed}/training_results.json').read_text())['test_metrics']['accuracy']
            for seed in (42, 123, 2024, 3333)]
print(ttest_rel(scores('04_phase3_vn_mangoleaf'), scores('05_direct_vn_from_phase1')))
PY
```

Luận văn báo `p ≈ 0,025`, `n=4`; đây là kết quả tham khảo do ít seed và dùng chung tập test. Các con số trên là mục tiêu đối chiếu từ bằng chứng đã lưu, không bảo đảm giống từng chữ số khi thay phần cứng, phiên bản, dữ liệu hoặc cách resume. Trainer hiện tại đã được so với file đang có trên host: khác đường import model, quy tắc đặt tên output và cách truyền danh sách stage rỗng. Hash nguồn host hôm nay chưa chứng minh được danh tính mã của từng lượt huấn luyện lịch sử.

### 7.1. Vị trí các bảng trong luận văn

| Bảng | Trang in / PDF | Bằng chứng |
|---|---|---|
| 4.1, 4.2 | 55-56 / 58-59 | [Thông tin môi trường](environment/asus/host-environment.json), `experiments/*/args.yaml` và cấu hình runner |
| 4.3 | 57 / 60 | `01_phase1_mangoleafbd_320_seed_*/training_results.json` |
| 4.4 | 58 / 61 | Năm nhóm `02_ablation_*_224_seed_*/training_results.json` |
| 4.5, 4.6 | 59 / 62 | `03_phase2_combined_320_seed_*` và `04_phase3_vn_mangoleaf_320_seed_*` |
| 4.7 | 60 / 63 | [per_class_metrics.csv](experiments/04_phase3_vn_mangoleaf_320_seed_42/per_class_metrics.csv) và `test_per_class_metrics` của phase 3 seed 42 |
| 4.8 | 64 / 67 | Phase 3 và `05_direct_vn_from_phase1_320_seed_*`, ghép cùng seed |
| 4.9 | 66 / 69 | Phase 1, [gpu_latency_summary.json](experiments/01_phase1_mangoleafbd_320_seed_3333/gpu_latency_summary.json) và các nghiên cứu tham chiếu trong PDF |

Các mô hình khác trong Bảng 4.9 là số liệu trích từ nghiên cứu đã công bố, dùng phần cứng/giao thức khác nhau. Repository chưa có runner để tái huấn luyện các baseline đó trong cùng điều kiện.

<a id="hinh-thuc-nghiem"></a>

## 8. Hình thực nghiệm trong luận văn và nguồn gốc

Các hình sau được trích từ chính PDF đã cung cấp. Với hình kết quả, đường dẫn `experiments/` chỉ tới dữ liệu tạo hình; các ảnh gốc có độ phân giải cao hơn vẫn được giữ trong lượt thí nghiệm tương ứng. Chọn checkpoint tốt nhất theo validation loss trong mỗi lượt khác với chọn một seed để minh họa: seed 3333/123/42 được luận văn chọn hậu nghiệm theo test accuracy cao nhất của từng bộ dữ liệu, chỉ phục vụ mô tả.

### 8.1. Giao diện Android (Hình 4.1)

![Hình 4.1. Giao diện ứng dụng Android nhận diện và hiển thị CAM](docs/figures/thesis_fig_4_1_android_ui.png)

Nguồn ảnh: [trang in 54, trang PDF 57](Luận%20văn%20thạc%20sĩ.pdf#page=57). Đây là ảnh giao diện nhúng trong luận văn, không phải ảnh chụp thiết bị mới của lần chuẩn bị README. Mã giao diện: [MainActivity.kt](android/app/src/main/java/com/mangomamba/benchmark/MainActivity.kt); thông tin model: [manifest runtime](android/app/src/main/assets/mango_mamba_v3_phase3_320_cam_manifest.json). Chưa có file ảnh chụp gốc độc lập hoặc log thiết bị để kiểm chứng lại lần chụp này.

### 8.2. Đường cong huấn luyện VN-MangoLeaf (Hình 4.2)

![Hình 4.2. Đường cong huấn luyện VN-MangoLeaf giai đoạn 3 seed 42](docs/figures/thesis_fig_4_2_training_vn_seed42.png)

Nguồn ảnh: [trang in 60, trang PDF 63](Luận%20văn%20thạc%20sĩ.pdf#page=63). Nguồn thực nghiệm: [training_curves.png](experiments/04_phase3_vn_mangoleaf_320_seed_42/training_curves.png) của phase 3 seed 42, do hàm `plot_training_curves` trong [trainer](code/train_mango_mamba.py) tạo từ lịch sử train/validation. Hình mô tả riêng lượt seed 42.

### 8.3. Ma trận nhầm lẫn MangoLeafBD (Hình 4.3)

![Hình 4.3. Ma trận nhầm lẫn MangoLeafBD seed 3333](docs/figures/thesis_fig_4_3_confusion_mangoleafbd_seed3333.png)

Nguồn ảnh: [trang in 62, trang PDF 65](Luận%20văn%20thạc%20sĩ.pdf#page=65). Nguồn thực nghiệm: [confusion_matrix_test.png](experiments/01_phase1_mangoleafbd_320_seed_3333/confusion_matrix_test.png) và [training_results.json](experiments/01_phase1_mangoleafbd_320_seed_3333/training_results.json), phase 1 seed 3333, test 400 ảnh. [Trainer](code/train_mango_mamba.py) đánh giá checkpoint đã chọn và vẽ ma trận; checkpoint này dự đoán đúng 400/400 ảnh.

### 8.4. Ma trận nhầm lẫn Bộ dữ liệu kết hợp (Hình 4.4)

![Hình 4.4. Ma trận nhầm lẫn Bộ dữ liệu kết hợp seed 123](docs/figures/thesis_fig_4_4_confusion_combined_seed123.png)

Nguồn ảnh: [trang in 62, trang PDF 65](Luận%20văn%20thạc%20sĩ.pdf#page=65). Nguồn thực nghiệm: [confusion_matrix_test.png](experiments/03_phase2_combined_320_seed_123/confusion_matrix_test.png) và [training_results.json](experiments/03_phase2_combined_320_seed_123/training_results.json), phase 2 seed 123, test 4.000 ảnh, accuracy 99,575%. Script tạo hình: [trainer](code/train_mango_mamba.py).

### 8.5. Ma trận nhầm lẫn VN-MangoLeaf (Hình 4.5)

![Hình 4.5. Ma trận nhầm lẫn VN-MangoLeaf seed 42](docs/figures/thesis_fig_4_5_confusion_vn_seed42.png)

Nguồn ảnh: [trang in 63, trang PDF 66](Luận%20văn%20thạc%20sĩ.pdf#page=66). Nguồn thực nghiệm: [confusion_matrix_test.png](experiments/04_phase3_vn_mangoleaf_320_seed_42/confusion_matrix_test.png), [training_results.json](experiments/04_phase3_vn_mangoleaf_320_seed_42/training_results.json) và [bản phân tích lỗi](experiments/04_phase3_vn_mangoleaf_320_seed_42/error_analysis_summary.json). Checkpoint phase 3 seed 42 đúng 695/700 ảnh; cả năm lỗi thuộc lớp thật Anthracnose. Script tạo hình trong lượt huấn luyện: [trainer](code/train_mango_mamba.py).

### 8.6. Độ chính xác theo seed (Hình 4.6)

![Hình 4.6. Test accuracy theo bốn seed trên ba bộ dữ liệu](docs/figures/thesis_fig_4_6_accuracy_by_seed.png)

Nguồn ảnh: [trang in 64, trang PDF 67](Luận%20văn%20thạc%20sĩ.pdf#page=67). Nguồn số liệu: 12 file `training_results.json` của phase 1, 2 và 3, trường `test_metrics.accuracy`; bốn seed `42, 123, 2024, 3333`. [render_thesis_figures.py](code/render_thesis_figures.py) tạo bản đối chiếu từ cùng số liệu, với nhãn/màu khác bản tiếng Việt trong PDF; danh sách 12 file và hash nằm trong [derived_figures_manifest.json](docs/figures/derived_figures_manifest.json). Trục tung bắt đầu từ 98%.

### 8.7. Grad-CAM bảy lớp VN-MangoLeaf (Hình 4.7)

![Hình 4.7. Grad-CAM của bảy lớp VN-MangoLeaf seed 42](docs/figures/thesis_fig_4_7_gradcam_vn_seed42.png)

Nguồn ảnh: bảy panel ở [trang in 68-69, trang PDF 71-72](Luận%20văn%20thạc%20sĩ.pdf#page=71); caption ở [trang in 70, trang PDF 73](Luận%20văn%20thạc%20sĩ.pdf#page=73). Nguồn thực nghiệm: bảy file `gradcam_*.png` trong [phase 3 seed 42](experiments/04_phase3_vn_mangoleaf_320_seed_42/), theo thứ tự Healthy, Anthracnose, Gall Midge, Powdery Mildew, Sooty Mold, Dieback, Red Rust. [Trainer](code/train_mango_mamba.py) dùng ảnh đầu tiên của mỗi lớp trong bộ nạp validation và tính Grad-CAM cho lớp thật tại BatchNorm2d cuối; [renderer](code/render_thesis_figures.py) ghép panel. Mỗi hàng gồm ảnh gốc, bản đồ nhiệt và ảnh phủ. Đây là trực quan hóa đóng góp cho dự đoán, chưa chứng minh khả năng phân đoạn tổn thương.

### 8.8. Ba trường hợp dự đoán sai (Hình 4.8)

![Hình 4.8. Ba lỗi Anthracnose bị dự đoán sang Gall Midge, Sooty Mold và Red Rust](docs/figures/thesis_fig_4_8_errors_vn_seed42.png)

Nguồn ảnh: hai panel ở [trang in 70, trang PDF 73](Luận%20văn%20thạc%20sĩ.pdf#page=73), panel cuối và caption ở [trang in 71, trang PDF 74](Luận%20văn%20thạc%20sĩ.pdf#page=74). Nguồn thực nghiệm: `error_001_*_cam.png`, `error_002_*_cam.png`, `error_003_*_cam.png` và [misclassifications.csv](experiments/04_phase3_vn_mangoleaf_320_seed_42/misclassifications.csv). [analyze_vn_errors.py](code/analyze_vn_errors.py) tạo CAM từ feature map cuối và trọng số classifier, sắp xếp lỗi theo confidence giảm dần; [renderer](code/render_thesis_figures.py) ghép ba panel. Nhãn thật đều là Anthracnose; nhãn dự đoán tương ứng Gall Midge (0,911), Sooty Mold (0,876), Red Rust (0,872).

<a id="phan-tich"></a>

## 9. Phân tích lỗi, tạo lại hình và đo latency GPU

### 9.1. Phân tích lỗi và ghép hình

Chọn bộ bằng chứng cũ hoặc kết quả mới bằng biến `RESULTS`:

```bash
RESULTS="$PWD/experiments"
# Để dùng lượt mới, thay dòng trên bằng: RESULTS="$OUT"
VN="$RESULTS/04_phase3_vn_mangoleaf_320_seed_42"
ANALYSIS="$OUT/vn_seed42_analysis"

python code/analyze_vn_errors.py \
  --checkpoint "$VN/model_best.pth.tar" \
  --data-dir "$DATA_ROOT/vn_mangoleaf" \
  --source-args "$VN/args.yaml" \
  --output "$ANALYSIS"
```

Output phải là thư mục chưa tồn tại. Script tạo `summary.json`, `per_class_metrics.csv`, `misclassifications.csv`, `confusion_matrix_test.png`, ảnh sai và các panel `error_*_cam.png`. Với checkpoint gốc seed 42 và đúng test split, có 5 ảnh sai, đều là Anthracnose bị dự đoán thành Gall Midge, Red Rust hoặc Sooty Mold. Seed 42 được chọn hậu nghiệm theo test accuracy cao nhất; Bảng 4.7 mô tả riêng checkpoint này.

Ghép hình từ bộ bằng chứng cũ vào output mới:

```bash
python code/render_thesis_figures.py \
  --experiments experiments --output "$OUT/figures_from_retained"
```

Để ghép hình từ lượt chạy mới, đưa panel ảnh sai vào chính lượt VN mới rồi gọi renderer:

```bash
# Chỉ thực hiện khi RESULTS trỏ tới bộ lượt mới trong runs/.
cp -n "$ANALYSIS"/error_*_cam.png "$VN/"
python code/render_thesis_figures.py \
  --experiments "$RESULTS" --output "$OUT/figures_from_rerun"
```

Renderer lưu hash nguồn trong `derived_figures_manifest.json`. Lượt mới cần đủ bảy Grad-CAM và ít nhất ba ảnh sai để tạo Hình 4.7/4.8; trainer có thể tiếp tục sau lỗi tạo Grad-CAM nên cần kiểm tra log nếu thiếu panel. Mã vẽ Hình 4.6 hiện kiểm tra accuracy nằm trong khoảng 98-100%; lượt thấp hơn sẽ dừng để tránh cắt mất dữ liệu trên trục y.

### 9.2. Đo latency GPU

```bash
python code/measure_gpu_latency.py \
  --checkpoint "$RESULTS/01_phase1_mangoleafbd_320_seed_3333/model_best.pth.tar" \
  --data-dir "$DATA_ROOT/mangoleafBD" \
  --warmup 100 --samples 500 \
  --output "$OUT/gpu_latency_seed3333"

```

Benchmark đo riêng model forward, batch 1, FP32, input 320×320 trên GPU; không gồm đọc ảnh/tiền xử lý và được ghi riêng với phép đo điện thoại. Output có `latency_samples_ms.csv` và `summary.json`. Tham chiếu trong luận văn trên GB10 là mean 4,566 ms, SD 0,130 ms, median 4,545 ms, p95 4,594 ms.

<a id="android"></a>

## 10. Xuất ONNX và ứng dụng Android

### 10.1. Xuất checkpoint phase 3 seed 42

```bash
python code/export_android_cam.py \
  --checkpoint "$VN/model_best.pth.tar" \
  --output "$OUT/android/mango_mamba_v3_phase3_320_cam.onnx"
```

Exporter tạo ONNX và `<stem>_manifest.json`, kiểm tra `onnx.checker` và so sánh PyTorch/ONNX Runtime trên một tensor ngẫu nhiên với sai số tuyệt đối tối đa `1e-3`. Input `[1,3,320,320]`, output logits `[1,7]`, feature map `[1,384,10,10]`. Một tensor parity chưa thay thế đánh giá trên toàn bộ tập test.

Ứng dụng Kotlin nạp cặp [model ONNX](android/app/src/main/assets/mango_mamba_v3_phase3_320_cam.onnx) và [manifest runtime](android/app/src/main/assets/mango_mamba_v3_phase3_320_cam_manifest.json). Tiền xử lý: resize cạnh ngắn 366, center crop 320, chuẩn hóa ImageNet. Nhãn bắt buộc theo thứ tự: `Anthracnose`, `Dieback`, `Gall_Midge`, `Healthy`, `Powdery_Mildew`, `Red_Rust`, `Sooty_Mold`.

CAM dùng `ReLU(sum_k F[k,y,x] * classifier.weight[class,k])`, chia cho giá trị lớn nhất dương rồi nội suy song tuyến. Trong kiến trúc GAP + linear, CAM này tương đương Grad-CAM tới một hệ số dương trước chuẩn hóa; đây là bản đồ chú ý thô, không phải phân đoạn. Trọng số classifier trong manifest phải đi cùng ONNX.

### 10.2. Nguồn trọng số và checksum

| Thành phần | SHA-256 |
|---|---|
| [Checkpoint phase 3 seed 42](experiments/04_phase3_vn_mangoleaf_320_seed_42/model_best.pth.tar) | `208b07937526b35260767afa62da43616d8a0245ba1fd7680102990bc34ae8ae` |
| ONNX đang dùng | `f312db7a8046e8481063752393450dc985d85ef2ac59aec3131cbbd8a081e3a4` |

[Manifest export gốc](experiments/04_phase3_vn_mangoleaf_320_seed_42/android_export_manifest.json) và [log export](experiments/04_phase3_vn_mangoleaf_320_seed_42/android_export.log) ghi ONNX checker qua, sai số logits `1.1920928955078125e-06` và feature map `6.4373016357421875e-06`, tolerance `0.001`.

### 10.3. Build và kiểm tra thiết bị

Cần JDK 17 và Android SDK có platform 34. Thiết lập `JAVA_HOME`, `ANDROID_HOME` theo máy hiện tại, hoặc tạo `android/local.properties` với `sdk.dir`.

```powershell
# Từ gốc repo trên Windows:
cd android
.\gradlew.bat :app:assembleDebug
```

```bash
# Từ gốc repo trên Linux:
bash android/gradlew -p android :app:assembleDebug
```

APK tạo tại `android/app/build/outputs/apk/debug/app-debug.apk`. Sau khi cài APK và chép một ảnh vào đường dẫn kiểm tra trên điện thoại:

```powershell
adb shell am start -n com.mangomamba.benchmark/.MainActivity --es test_image_path /sdcard/Android/data/com.mangomamba.benchmark/files/test.jpg
```

Ứng dụng nhận thêm `test_batch_manifest_path` để đánh giá một danh sách ảnh. Khi cập nhật model, chép cả ONNX/manifest dưới đúng tên asset, build, kiểm tra trên điện thoại và ghi hash APK/ONNX/manifest cùng raw benchmark mới.

Luận văn báo Redmi Note 11S, Android 13, FP32, 50 lần cùng một ảnh: mean 612,80 ms, SD 48,47 ms, median 598,48 ms, p95 718,51 ms. Workspace hiện thiếu raw CSV/log và APK tương ứng để tái kiểm chứng phép đo. APK 224px cũ có hash `dda3b386a7ebc7be6d1031ff5214abe3162c3f4f8025569c1ca604bcc4731178`; đó là artifact khác, không dùng làm bằng chứng cho model CAM 320px. Hồ sơ lưu trữ cũ ghi vị trí `E:/Luan van thac si/Mango-Mamba-archive/2026-10-15-reorganization/`; vị trí này chưa được kiểm tra lại trong lần hợp nhất README.

<a id="nguon"></a>

## 11. Nguồn kiểm chứng và giới hạn tái lập

### 11.1. Bản xuất môi trường và nguồn ảnh

| File | Nội dung |
|---|---|
| [requirements-host-freeze.txt](environment/asus/requirements-host-freeze.txt) | `pip freeze --all` từ host: 173 gói, gồm cả công cụ notebook. Dùng làm constraints cho bộ cài gọn. |
| [installed-packages.json](environment/asus/installed-packages.json) | Tên và phiên bản các distribution đang cài. |
| [host-environment.json](environment/asus/host-environment.json) | Python, hệ điều hành, CPU/GPU, CUDA/nvcc, PyTorch/cuDNN, kiểm tra import và nguyên kết quả `pip check`. |
| [pyvenv.cfg](environment/asus/pyvenv.cfg) | Thông tin Python/uv gốc; chỉ lưu để truy vết. |
| [host-data-inventory.json](environment/asus/host-data-inventory.json) | Đếm ảnh theo bộ dữ liệu, split và tên thư mục lớp trên host; không chứa ảnh. |
| [host-source-hashes.json](environment/asus/host-source-hashes.json) | SHA-256 model/trainer trong cây `reproduce_mm` trên host; không đại diện cho model/trainer của workspace hiện tại. |
| [mamba-installed-metadata.json](environment/asus/mamba-installed-metadata.json) | Phiên bản, phụ thuộc và danh sách file Mamba cài trên host. |
| [mamba-wheel-provenance.json](environment/asus/mamba-wheel-provenance.json) | Nguồn, ABI, hash wheel và SHA-256 từng file đóng gói. |
| [workspace-smoke-test.log](environment/asus/workspace-smoke-test.log) | Kết quả chạy `code/check_environment.py` của workspace hiện tại trên venv gốc. |
| [clean-install.log](environment/asus/clean-install.log), [clean-mamba-install.log](environment/asus/clean-mamba-install.log) | Log dựng venv riêng trên cùng host từ các phiên bản khóa bằng uv và cài wheel Mamba bằng pip. |
| [clean-pip-check.log](environment/asus/clean-pip-check.log), [clean-smoke-test.log](environment/asus/clean-smoke-test.log) | Kết quả kiểm tra trên venv mới; chưa qua đầy đủ, xem lý do bên dưới. |
| [validation-report.json](environment/asus/validation-report.json) | Tổng hợp kiểm tra đã qua, lỗi và phần chưa xác minh. |

| File bổ sung | Nội dung |
|---|---|
| [thesis_images_manifest.json](docs/figures/thesis_images_manifest.json) | Hash PDF, vị trí/object của 11 hình trích, hash ảnh và file thực nghiệm liên quan |
| [derived_figures_manifest.json](docs/figures/derived_figures_manifest.json) | 12 JSON, bảy Grad-CAM và ba panel lỗi dùng cho bản hình ghép trong repo |
| [retained-thesis-results.csv](environment/asus/retained-thesis-results.csv) | Thống kê tính lại từ 36 JSON hiện có |
| [export-manifest.json](environment/asus/export-manifest.json) | Hash file trong bộ cấu hình và hash 36 JSON đầu vào |

Bản [ZIP cấu hình](environment/mango_thesis_linux_wsl2_config.zip) dùng để chép vào một bản repository hiện có. ZIP gồm README này, mã Python, ảnh minh họa và cấu hình môi trường; không gồm PDF, dữ liệu ảnh đầy đủ, checkpoint hoặc wheel ARM64 lớn. Requirements và log là file dữ liệu hỗ trợ; README này là tài liệu hướng dẫn duy nhất của repository.

### 11.2. Kiểm tra đã thực hiện

| Hạng mục | Kết quả đã ghi nhận |
|---|---|
| Venv gốc trên asus | Import, AMP forward/backward, gradient selective scan và FP32 forward qua ở 224px/8 lớp và 320px/7 lớp |
| Venv mới `/tmp/mango_clean_venv_20261105` | Cài 97 distribution khớp phiên bản nguồn; import và cấp phát một tensor CUDA qua |
| Mô hình đầy đủ trên venv mới | Bị CUDA OOM trong lần thử; lúc chẩn đoán, ba tiến trình vLLM giữ khoảng 99 GiB và CUDA báo còn khoảng 2,1 GiB trống |
| `pip check` trên cả hai venv | Trả mã 1: `nvidia-cusparselt-cu13 0.8.1 is not supported on this platform` |
| Runner và tổng hợp | 5 kiểm tra runner, 2 kiểm tra thống kê đã qua; hình 4.6/4.7/4.8 đã được tạo lại vào output tạm |
| Tái huấn luyện 36 lượt | Chưa thực hiện; số liệu README tính từ JSON đã lưu |
| Cài WSL2/x86_64 và build Mamba x86_64 | Chưa kiểm tra trực tiếp |

Venv mới được dựng riêng bằng uv với hai chỉ mục PyPI/PyTorch cu130, constraints từ host và wheel Mamba đóng gói lại. Venv nguồn không bị thay đổi. Các số bộ nhớ trên là trạng thái tại lần kiểm tra được ghi log; không phải tình trạng máy chủ được cập nhật liên tục. `setup_linux.sh` trả lỗi nếu kiểm tra mô hình hoặc `pip check` thất bại.

Hai manifest lịch sử `docs/REORGANIZATION_MANIFEST.json` và `docs/CHECKPOINT_SYNC_MANIFEST.json` hiện thiếu trong checkout. Vì vậy hai kiểm tra kho bằng chứng phụ thuộc chúng chưa chạy được; không tạo manifest thay thế để giả lập provenance cũ. Hiện có 36 JSON và 16 checkpoint chính, còn thiếu 20 checkpoint ablation. Bản kiểm kê dữ liệu mới chỉ đếm ảnh, chưa có hash toàn bộ split.

Ảnh Hình 4.1 đã được lấy từ PDF để hiển thị trong README; ảnh chụp gốc độc lập và raw benchmark điện thoại 50 lần vẫn thiếu. Trực quan hóa CAM mô tả phản hồi của mô hình, chưa xác nhận khả năng định vị tổn thương bằng nhãn phân đoạn.

### 11.3. Wheel Mamba ARM64 dự phòng

`environment/asus/wheels/mamba_ssm-2.3.2.post1-cp312-cp312-linux_aarch64.whl` có kích thước 349.455.308 byte, khoảng 333,3 MiB. Đây là bản đóng gói lại distribution đã cài, dùng công cụ [wheel pack](https://wheel.readthedocs.io/en/stable/reference/wheel_pack.html); không phải wheel phát hành chính thức từ upstream. Các file payload, gồm extension CUDA, đã được so hash và khớp từng byte với bản lấy từ host; `RECORD` được tạo lại theo định dạng wheel.

Chỉ dùng với Linux ARM64 + CPython 3.12 + PyTorch 2.13.0+cu130/CUDA 13.0 và kiểm tra lại trên GPU đích. SHA-256 của wheel:

```text
f2747c549eadf330e350e9ffe75885866f23cd6de65910f87407d6be0801fe51
```

Linux/WSL2 x86_64 phải build hoặc cài wheel Mamba tương ứng; wheel này không dùng được trên x86_64. Gói binary được để riêng để bộ cấu hình văn bản vẫn gọn. Xem [Mamba 2.3.2.post1](https://github.com/state-spaces/mamba/tree/v2.3.2.post1) để đối chiếu cách cài từ mã nguồn.
